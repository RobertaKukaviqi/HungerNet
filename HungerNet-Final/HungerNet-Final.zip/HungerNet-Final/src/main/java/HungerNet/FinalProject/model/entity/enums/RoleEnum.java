package HungerNet.FinalProject.model.entity.enums;

public enum RoleEnum {
    ADMIN,
    RESTAURANT_MANAGER,
    CLIENT
}
