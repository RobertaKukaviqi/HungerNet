package HungerNet.FinalProject.model.entity.enums;

public enum OrderStatusEnum {
    CREATED,
    REJECTED,
    APPROVED,
    PREPARED,
    WAITING_FOR_DELIVERY,
    DELIVERED,

}
